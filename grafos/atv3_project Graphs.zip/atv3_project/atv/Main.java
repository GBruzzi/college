package atv;

import java.io.*;
import java.util.*;

class Edge {
   int u;
   int v;
   double weight;

   public Edge(int var1, int var2) {
      this(var1, var2, 1.0);
   }

   public Edge(int var1, int var2, double weight) {
      this.u = var1;
      this.v = var2;
      this.weight = weight;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         Edge var2 = (Edge)var1;
         return this.u == var2.u && this.v == var2.v;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(this.u, this.v);
   }
}

class Graph {
   private final int vertices;
   private final List<List<Edge>> adjList;
   private final List<Edge> edges;
   private final boolean[] visited;
   private final List<Edge> treeEdges;

   public Graph(int var1) {
      this.vertices = var1;
      this.adjList = new ArrayList<>();
      this.edges = new ArrayList<>();
      this.visited = new boolean[var1 + 1];
      this.treeEdges = new ArrayList<>();

      for(int var2 = 0; var2 <= var1; ++var2) {
         this.adjList.add(new ArrayList<>());
      }
   }

   public void addEdge(int var1, int var2) {
      this.addEdge(var1, var2, 1.0);
   }

   public void addEdge(int var1, int var2, double weight) {
      Edge edge = new Edge(var1, var2, weight);
      this.adjList.get(var1).add(edge);
      this.edges.add(edge);
   }

   public void sortEdges() {
      for (List<Edge> var2 : this.adjList) {
         Collections.sort(var2, (e1, e2) -> Integer.compare(e1.v, e2.v));
      }
   }

   public void dfs(int var1) {
      this.visited[var1] = true;
      for (Edge edge : this.adjList.get(var1)) {
         if (!this.visited[edge.v]) {
            this.treeEdges.add(edge);
            this.dfs(edge.v);
         }
      }
   }

   public void classifyEdges(int var1) {
      for (Edge var3 : this.edges) {
         if (var3.u == var1) {
            if (this.treeEdges.contains(var3)) {
               System.out.println("Aresta de arvore: " + var3.u + " -> " + var3.v);
            } else {
               System.out.println("Aresta Divergente: " + var3.u + " -> " + var3.v);
            }
         }
      }
   }

   //Variação de Dijkstra
   public PathResult findShortestPath(int source, int target) {
      double[] distances = new double[vertices + 1];
      int[] edgesCount = new int[vertices + 1];
      int[] previous = new int[vertices + 1];

      for (int i = 0; i <= vertices; i++) {
         distances[i] = Double.POSITIVE_INFINITY;
         edgesCount[i] = Integer.MAX_VALUE;
         previous[i] = -1;
      }

      distances[source] = 0;
      edgesCount[source] = 0;

      PriorityQueue<VertexInfo> pq = new PriorityQueue<>();
      pq.add(new VertexInfo(source, 0, 0));

      while (!pq.isEmpty()) {
         VertexInfo current = pq.poll();
         int u = current.vertex;

         if (current.distance > distances[u] || 
             (current.distance == distances[u] && current.edges > edgesCount[u])) {
            continue;
         }

         for (Edge edge : adjList.get(u)) {
            int v = edge.v;
            double newDistance = distances[u] + edge.weight;
            int newEdges = edgesCount[u] + 1;

            if (newDistance < distances[v] || 
                (newDistance == distances[v] && newEdges < edgesCount[v])) {
               distances[v] = newDistance;
               edgesCount[v] = newEdges;
               previous[v] = u;
               pq.add(new VertexInfo(v, newDistance, newEdges));
            }
         }
      }

      if (distances[target] == Double.POSITIVE_INFINITY) {
         return null;
      }

      List<Integer> path = new ArrayList<>();
      for (int v = target; v != -1; v = previous[v]) {
         path.add(v);
      }
      Collections.reverse(path);

      return new PathResult(distances[target], edgesCount[target], path);
   }

   private static class VertexInfo implements Comparable<VertexInfo> {
      int vertex;
      double distance;
      int edges;

      public VertexInfo(int vertex, double distance, int edges) {
         this.vertex = vertex;
         this.distance = distance;
         this.edges = edges;
      }

      @Override
      public int compareTo(VertexInfo other) {
         int cmp = Double.compare(this.distance, other.distance);
         if (cmp != 0) return cmp;
         return Integer.compare(this.edges, other.edges);
      }
   }

   public static class PathResult {
      public final double totalDistance;
      public final int totalEdges;
      public final List<Integer> path;

      public PathResult(double totalDistance, int totalEdges, List<Integer> path) {
         this.totalDistance = totalDistance;
         this.totalEdges = totalEdges;
         this.path = path;
      }

      @Override
      public String toString() {
         return "Distancia total: " + totalDistance + 
                "\nNumero de arestas: " + totalEdges + 
                "\nCaminho: " + path;
      }
   }
}

public class Main {
   public static void main(String[] args) {
      try (Scanner sc = new Scanner(System.in)) {
         System.out.print("Digite o nome do arquivo do grafo: ");
         String filename = sc.nextLine();

         BufferedReader reader = new BufferedReader(new FileReader(filename));
         String[] parts = reader.readLine().split(" ");
         int n = Integer.parseInt(parts[0]); // número de vértices
         int m = Integer.parseInt(parts[1]); // número de arestas

         Graph graph = new Graph(n);

         for (int i = 0; i < m; i++) {
            String[] edgeLine = reader.readLine().split(" ");
            int u = Integer.parseInt(edgeLine[0]);
            int v = Integer.parseInt(edgeLine[1]);
            double w = Double.parseDouble(edgeLine[2]);
            graph.addEdge(u, v, w);
         }
         reader.close();

         System.out.print("Digite o vertice de origem: ");
         int origem = sc.nextInt();
         System.out.print("Digite o vertice de destino: ");
         int destino = sc.nextInt();

         long inicio = System.nanoTime(); // início da medição de tempo
         Graph.PathResult result = graph.findShortestPath(origem, destino);
         long fim = System.nanoTime(); // fim da medição de tempo

         if (result != null) {
            System.out.println("\nCaminho minimo encontrado:");
            System.out.println(result);
            System.out.printf("Tempo de execucao: %.4f ms\n", (fim - inicio) / 1e6);

            salvarResultado("saida_resultado.txt", origem, destino, result, (fim - inicio) / 1e6);
         } else {
            System.out.println("Nao ha caminho entre os vértices especificados.");
         }

      } catch (IOException e) {
         System.err.println("Erro ao ler o arquivo: " + e.getMessage());
      }
   }

   public static void salvarResultado(String arquivo, int origem, int destino, Graph.PathResult res, double tempo) {
      try (PrintWriter writer = new PrintWriter(new FileWriter(arquivo, true))) {
         writer.println("Origem: " + origem + ", Destino: " + destino);
         writer.println("Distancia total: " + res.totalDistance);
         writer.println("Numero de arestas: " + res.totalEdges);
         writer.println("Caminho: " + res.path);
         writer.printf("Tempo de execucao: %.4f ms\n", tempo);
         writer.println("----------------------------------------------------");
      } catch (IOException e) {
         System.err.println("Erro ao salvar resultado: " + e.getMessage());
      }
   }
}


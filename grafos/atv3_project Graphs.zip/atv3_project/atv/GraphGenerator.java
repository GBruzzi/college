package atv;

import java.io.*;
import java.util.*;

public class GraphGenerator {

    static class Edge {
        int from, to, weight;

        Edge(int from, int to, int weight) {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof Edge)) return false;
            Edge e = (Edge) o;
            return from == e.from && to == e.to;
        }

        @Override
        public int hashCode() {
            return Objects.hash(from, to);
        }
    }

    public static void generateGraph(String filename, int vertices, int edges, int maxWeight) throws IOException {
        if (edges < vertices - 1) {
            throw new IllegalArgumentException("Número de arestas deve ser pelo menos (vértices - 1) para garantir conexão.");
        }

        Random rand = new Random();
        Set<Edge> edgeSet = new HashSet<>();
        List<Integer> connected = new ArrayList<>();
        List<Integer> unconnected = new ArrayList<>();

        for (int i = 1; i <= vertices; i++) {
            unconnected.add(i);
        }

        // Garante conexão: cria uma árvore aleatória
        connected.add(unconnected.remove(rand.nextInt(unconnected.size())));
        while (!unconnected.isEmpty()) {
            int from = connected.get(rand.nextInt(connected.size()));
            int to = unconnected.remove(rand.nextInt(unconnected.size()));
            int weight = rand.nextInt(maxWeight) + 1;
            edgeSet.add(new Edge(from, to, weight));
            connected.add(to);
        }

        // Arestas extras
        while (edgeSet.size() < edges) {
            int from = rand.nextInt(vertices) + 1;
            int to = rand.nextInt(vertices) + 1;
            if (from != to) {
                Edge e = new Edge(from, to, rand.nextInt(maxWeight) + 1);
                edgeSet.add(e);
            }
        }

        // Salva em arquivo
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println(vertices + " " + edgeSet.size());
            for (Edge e : edgeSet) {
                writer.println(e.from + " " + e.to + " " + e.weight);
            }
        }

        System.out.println("Grafo salvo em: " + filename);
    }

    public static void main(String[] args) throws IOException {
        // Exemplos de uso:
        generateGraph("grafo5.txt", 5, 7, 10);
        generateGraph("grafo50.txt", 50, 100, 15);
        generateGraph("grafo100.txt", 100, 250, 20);
        generateGraph("grafo500.txt", 500, 1500, 30);
    }
}
